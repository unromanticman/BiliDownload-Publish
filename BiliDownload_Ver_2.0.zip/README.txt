﻿# BiliDownload-Publish
BiliDownload B站資源下載器打包版


程式名稱：BiliDownload

作者:UM / 20160201

功用：可以迅速的下載B站影片，且不會中斷，同時有進度條顯示。

下載的檔案將儲存至BiliDownload資料夾。